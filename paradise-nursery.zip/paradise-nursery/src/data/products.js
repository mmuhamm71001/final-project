// Paradise Nursery product catalog
// Each plant belongs to a category and carries a simple SVG-based thumbnail
// (a colored circle + emoji) so the project stays fully self-contained
// with no external image dependencies.

export const categories = [
  {
    id: "aromatic",
    name: "Aromatic Fragrant Plants",
    description:
      "Fill your home with natural fragrance. These plants are prized for their pleasant, calming scents.",
  },
  {
    id: "insect-repellent",
    name: "Insect Repellent Plants",
    description:
      "Keep bugs away the natural way. These plants naturally discourage mosquitoes and other pests.",
  },
  {
    id: "air-purifying",
    name: "Air Purifying Plants",
    description:
      "Breathe easier. These plants are known for filtering common household toxins from the air.",
  },
  {
    id: "low-maintenance",
    name: "Low Maintenance Plants",
    description:
      "Perfect for busy schedules or first-time plant parents — hard to kill, easy to love.",
  },
];

export const products = [
  {
    id: 1,
    name: "Lavender",
    price: 15.0,
    category: "aromatic",
    color: "#9b8fd4",
    emoji: "💐",
    description: "A calming, fragrant herb with soft purple blooms.",
  },
  {
    id: 2,
    name: "Jasmine",
    price: 18.5,
    category: "aromatic",
    color: "#f4f1e8",
    emoji: "🌼",
    description: "Sweetly scented white flowers that bloom in the evening.",
  },
  {
    id: 3,
    name: "Rosemary",
    price: 12.0,
    category: "aromatic",
    color: "#7fa66b",
    emoji: "🌿",
    description: "A woody, aromatic herb loved in both gardens and kitchens.",
  },
  {
    id: 4,
    name: "Citronella",
    price: 16.0,
    category: "insect-repellent",
    color: "#8fbf6b",
    emoji: "🌱",
    description: "A lemon-scented grass that naturally repels mosquitoes.",
  },
  {
    id: 5,
    name: "Lemongrass",
    price: 14.0,
    category: "insect-repellent",
    color: "#a8d06a",
    emoji: "🌾",
    description: "Tall, fragrant grass that keeps bugs at bay.",
  },
  {
    id: 6,
    name: "Marigold",
    price: 10.0,
    category: "insect-repellent",
    color: "#f4a340",
    emoji: "🌻",
    description: "Bright, cheerful blooms that deter garden pests.",
  },
  {
    id: 7,
    name: "Snake Plant",
    price: 22.0,
    category: "air-purifying",
    color: "#4f7a5c",
    emoji: "🪴",
    description: "A striking, upright plant that filters indoor air.",
  },
  {
    id: 8,
    name: "Peace Lily",
    price: 20.0,
    category: "air-purifying",
    color: "#e8ebe3",
    emoji: "🌺",
    description: "Elegant white blooms with excellent air-purifying power.",
  },
  {
    id: 9,
    name: "Spider Plant",
    price: 13.5,
    category: "air-purifying",
    color: "#6fae6a",
    emoji: "🪴",
    description: "An easy-going plant known for clearing indoor toxins.",
  },
  {
    id: 10,
    name: "Succulent Trio",
    price: 17.0,
    category: "low-maintenance",
    color: "#8fbf9b",
    emoji: "🌵",
    description: "Three hardy succulents that thrive on neglect.",
  },
  {
    id: 11,
    name: "ZZ Plant",
    price: 24.0,
    category: "low-maintenance",
    color: "#3f6b4a",
    emoji: "🌿",
    description: "Glossy leaves and near-indestructible durability.",
  },
  {
    id: 12,
    name: "Pothos",
    price: 11.0,
    category: "low-maintenance",
    color: "#78b06a",
    emoji: "🍃",
    description: "A trailing vine that forgives even the busiest schedules.",
  },
];
